const express=require('express');

const router=express.Router();


router.get('/api/v1/products/')



router.use('/api',require('./api'))



module.exports=router;

